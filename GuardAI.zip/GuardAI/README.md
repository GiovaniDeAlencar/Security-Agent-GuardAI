# 🛡️ DIO Security Agent

<p align="center">
  <img src="https://img.shields.io/badge/Security-AppSec%20%7C%20DevSecOps-red?style=for-the-badge&logo=shield" alt="Security Badge" />
  <img src="https://img.shields.io/badge/Standards-OWASP%20%7C%20CWE%20%7C%20NIST-blue?style=for-the-badge" alt="Standards Badge" />
  <img src="https://img.shields.io/badge/Status-Production%20Ready-success?style=for-the-badge" alt="Status Badge" />
</p>

> **Seu consultor e especialista sênior com Inteligência Artificial em Cibersegurança, Application Security (AppSec), Threat Modeling e Engenharia de Segurança.**

O **DIO Security Agent** é um agente autônomo projetado para atuar com o rigor metodológico de um *Lead Security Engineer* ou *AppSec Specialist*. Ele não apenas aponta falhas teóricas, mas realiza análises de causa-raiz, aplica diretamente correções de código no padrão da indústria (*Security by Default*), avalia riscos conforme matrizes globais (OWASP, CWE, CVSS, MITRE ATT&CK, NIST) e gerencia repositórios locais de códigos remediados e relatórios executivos em PDF.

---

## 🎯 Quem o Agente Atende

- **Desenvolvedores de Software:** Hardening de código, identificação de vulnerabilidades (SQLi, XSS, SSRF, Broken Auth) e refatoração segura.
- **Engenheiros de AppSec & DevSecOps:** Automação de segurança em esteiras CI/CD (SAST/DAST/SCA), auditoria de contêineres e IaC (Docker, K8s, Terraform).
- **Arquitetos de Sistemas:** Modelagem de ameaças arquiteturais orientada ao framework **STRIDE**.
- **Analistas de SOC / Blue Team:** Análise forense de logs, triagem de incidentes, identificação de IoCs e simulações com base no **NIST SP 800-61**.

---

## 🚀 Como Executar o Agente

O DIO Security Agent é construído sobre o padrão aberto de especificação de agentes (`AGENTS.md`), sendo compatível nativamente com harnesses como **Google Antigravity**, **Claude Code**, **Codex**, entre outros.

### 1. Clonar o Repositório
```bash
git clone https://github.com/seu-usuario/dio-security-agent.git
cd dio-security-agent
```

### 2. Inicializar no seu Harness Preferido
- **Google Antigravity / Claude Code:** Abra a pasta no ambiente. O arquivo `AGENTS.md` (e o ponteiro `CLAUDE.md`) será carregado automaticamente, ativando a persona sênior e as skills especializadas.

### 3. Enviar Instruções ou Códigos
Basta interagir diretamente via chat enviando um trecho de código, log de servidor ou cenário de arquitetura.

---

## 🧩 Matriz de Skills Especializadas

| Skill | Escopo Operacional | Padrão / Framework |
| :--- | :--- | :--- |
| **[Análise de Vulnerabilidades](skills/vulnerability-analysis/SKILL.md)** | Identifica vulnerabilidades em código, entrega a melhor correção, avalia causa-raiz, cita ataques reais e gera relatório. | OWASP Top 10, CWE, CVSS v3.1/v4.0 |
| **[Análise de Logs de Segurança](skills/log-analysis/SKILL.md)** | Triagem de logs (Web, Auth, Firewalls, DBs) identificando IPs atacantes, vetores de invasão e IoCs. | MITRE ATT&CK, Syslog, Web Formats |
| **[Modelagem de Ameaças](skills/threat-modeling/SKILL.md)** | Mapeamento de fronteiras de confiança, ativos e superfícies de ataque em arquiteturas. | Metodologia STRIDE |
| **[Resposta a Incidentes](skills/incident-response-drill/SKILL.md)** | Planejamento de contenção, erradicação, recuperação e pós-incidente. | NIST SP 800-61 Rev. 2 |
| **[DevSecOps e CI/CD](skills/devsecops-pipeline/SKILL.md)** | Implementação de esteiras com SAST, DAST, SCA, Secrets e Container Scanning. | Shift-Left Security, GitHub Actions |
| **[Segurança em Nuvem e IaC](skills/cloud-iac-security/SKILL.md)** | Auditoria e hardening de Dockerfiles, manifests Kubernetes, Docker Compose e Terraform. | CIS Benchmarks, Least Privilege |
| **[Scripts PowerShell](skills/powershell-scripting/SKILL.md)** | Desenvolvimento e validação de scripts defensivos em PowerShell para administração segura. | Windows Security, Script Hardening |
| **[Pesquisa de Ameaças](skills/web-search/SKILL.md)** | Pesquisa e correlação de CVEs recentes, campanhas ativas e zero-days em fontes oficiais. | NVD, MITRE CVE, CISA KEV |

---

## 💻 Exemplos de Utilização

### 🛡️ Auditoria e Correção de Código (AppSec)
```text
Analise as vulnerabilidades deste código:
- Código / Função: [cole seu código]
- Linguagem / Stack: [ex.: Python / FastAPI, Node.js / Express, Java / Spring]
- Contexto de Execução: [ex.: Endpoint público de login, processamento de arquivos]

Identifique a falha (CWE/OWASP), forneça o código remediado com a melhor prática da indústria, explique o impacto e salve o resultado no repositório local.
```

### 🔍 Investigação Forense de Logs
```text
Analise estes logs de servidor para identificar anomalias:
- Tipo de Log: [ex.: Nginx access.log, AWS CloudTrail, Linux auth.log]
- Trecho do Log: [cole as linhas suspeitas]

Identifique os IPs de origem, técnica MITRE utilizada, se o ataque obteve sucesso e recomende ações imediatas de contenção.
```

### 📐 Modelagem de Ameaças Arquitetural
```text
Efetue a modelagem de ameaças para este microsserviço:
- Componentes: API Gateway, Serviço de Autenticação JWT, Banco PostgreSQL e Gateway de Pagamentos externo.
- Fronteiras de Confiança: Internet pública vs. VPC interna.
Classifique os riscos com STRIDE e ordene as mitigações por prioridade.
```

---

## 💾 Repositório Local de Artefatos

O agente gerencia ativamente um diretório estruturado local de trabalho para armazenar os produtos de suas análises:

```
dio-agent/
├── Repositorio/
│   ├── Codigos/        # Códigos auditados e remediados prontos para produção
│   ├── Relatorios/     # Relatórios técnicos e sumários executivos (PDF / HTML)
│   └── Scripts/        # Scripts defensivos e ferramentas de automação homologadas
```

---

## 📁 Estrutura do Repositório

```
├── AGENTS.md                   # Configuração mestre do agente e catálogo de skills
├── CLAUDE.md                   # Ponto de entrada para Claude Code
├── README.md                   # Documentação pública do projeto
├── agent/
│   ├── persona.md              # Postura técnica, tom de voz e diretrizes de consultoria
│   └── knowledge/              # Bases de conhecimento técnicas (OWASP, NIST, MITRE, DIO)
├── skills/                     # Guias procedurais detalhados para cada especialidade
├── scripts/                    # Scripts utilitários para conversão e compilação de relatórios
└── Repositorio/                # Diretório persistente de artefatos gerados
```

---

## ⚖️ Princípios Éticos e Operacionais

- **Segurança Estritamente Defensiva:** O DIO Security Agent atua exclusivamente para auditoria, remediação, fortalecimento de defesas e testes devidamente autorizados. Ele **nunca** desenvolve exploits maliciosos, malwares ou instruções para invasão de sistemas de terceiros.
- **Soluções Definitivas (Anti-Quick Fixes):** O agente não recomenda mitigações superficiais ou cosméticas (ex.: regex frágeis ou desabilitar alertas). Prioriza sempre soluções padrão da indústria como *Prepared Statements*, bibliotecas criptográficas robustas e arquiteturas resilientes.
- **Rigor e Integridade Técnica:** Toda classificação de severidade é fundamentada em evidências técnicas e alinhada às métricas de cálculo do **CVSS**.

---

<p align="center">
  Desenvolvido com foco em excelência técnica e maturidade de segurança da informação.
</p>
