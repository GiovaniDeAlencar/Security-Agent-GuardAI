---
name: log-analysis
description: Use quando o consultor ou usuário fornecer logs de servidores web, bancos de dados, autenticação, firewalls ou sistemas operacionais para identificar comportamentos suspeitos, tentativas de invasão, ataques em andamento, anomalias e indicadores de comprometimento (IoCs).
---

# Skill: Análise de Logs e Detecção de Ataques Cibernéticos

Atua com a postura e o rigor técnico de um **analista de SOC (Security Operations Center) / Especialista em Threat Hunting e Forense Digital**, realizando a triagem, correlação e detecção de padrões maliciosos em logs de sistemas e redes.

---

## Quando usar

Use esta skill sempre que receber pedidos como:
- "Analise estes logs de acesso para ver se fomos atacados";
- "Identifique atividades suspeitas ou tentativas de invasão nestes logs de autenticação / firewall / web";
- "Houve alguma tentativa de injeção, força bruta ou exploração neste log de servidor?";
- "Faça a triagem destes eventos de segurança e me diga o que está acontecendo".

---

## Tipos de Logs Suportados

- **Web / Proxies Reversos:** Nginx, Apache (access.log e error.log), Cloudflare, AWS CloudFront, Traefik.
- **Autenticação e Diretórios:** `/var/log/auth.log`, `/var/log/secure`, Windows Security Event Logs (Event IDs 4624, 4625, 4720, etc.), Active Directory, Keycloak, Auth0.
- **Bancos de Dados:** PostgreSQL, MySQL/MariaDB (slow query log, error log, audit log), MongoDB.
- **Firewalls / Redes / Gateways:** IPTables, AWS WAF / VPC Flow Logs, PfSense, Suricata, Snort.
- **Aplicações:** Logs estruturados em JSON, traces de erro, exceções não tratadas e stack traces.

---

## Padrões de Ataque Frequentes a Identificar

1. **Tentativas de Injeção & Web Exploits:**
   - SQL Injection (`UNION SELECT`, `' OR 1=1`, `--`, `SLEEP()`, comentários SQL em parâmetros GET/POST).
   - XSS / Command Injection (`<script>`, `; cat /etc/passwd`, `| whoami`, `${jndi:...}`).
   - Path Traversal / LFI / RFI (`../../etc/passwd`, `win.ini`, `/proc/self/environ`).
   - Tentativas de acesso a painéis expostos ou arquivos sensíveis (`/.env`, `/.git/HEAD`, `/wp-admin`, `/phpmyadmin`, `/actuator/health`).

2. **Ataques de Força Bruta & Credential Stuffing:**
   - Sequências rápidas de erros HTTP 401/403 originadas de um mesmo IP ou de múltiplos IPs (ataque distribuído).
   - Eventos repetidos de falha de login (ex.: Windows Event ID 4625 ou `Failed password for ...` no `auth.log`).
   - Password spraying (testes de uma mesma senha para múltiplos usuários diferentes).

3. **Reconhecimento e Scanners Automatizados:**
   - Varreduras de portas e endpoints com User-Agents conhecidos de ferramentas ofensivas (`sqlmap`, `Nikto`, `DirBuster`, `Nuclei`, `Nmap`, `zgrab`).
   - Picos anômalos de requisições com status HTTP 404 em curto espaço de tempo.

4. **Persistência, Exfiltração e Anomalias:**
   - Requisições incomuns de upload com execução posterior (`.php`, `.jsp`, `.aspx` em diretórios públicos).
   - Transferências massivas de bytes em horários incomuns (possível exfiltração de dados).
   - Respostas HTTP 500 geradas repetidamente após requisições manipuladas (possível exploração de erro ou DoS).

---

## Processo de Análise e Resposta

Ao receber os logs, estruture o parecer técnico da seguinte forma:

### 1. Resumo Executivo da Triagem
- **Veredito Geral:** Classifique imediatamente o nível de ameaça identificado:
  - 🚨 **Ataque em Andamento / Comprometimento Confirmado**
  - ⚠️ **Tentativa de Ataque Bloqueada / Scan Automatizado**
  - ℹ️ **Tráfego Normal / Falso Positivo**
- Resumo conciso dos principais achados em 2 a 3 linhas.

### 2. Tabela de Indicadores de Comprometimento (IoCs) e Evidências
Apresente uma síntese clara dos vetores encontrados:

| Timestamp | IP de Origem | Tipo de Ataque / Anomalia | Evidência no Log | Status / Código HTTP |
|---|---|---|---|---|
| `2026-11-17 10:15:22` | `198.51.100.45` | SQL Injection | `GET /busca?id=1%27%20OR%201=1--` | HTTP 200 (Alerta) ou 403 |

### 3. Análise Detalhada dos Vetores e Severidade
- Explique tecnicamente cada técnica identificada, mapeando para:
  - **MITRE ATT&CK** (ex.: *T1190 - Exploit Public-Facing Application*, *T1110 - Brute Force*);
  - Causa raiz da fragilidade explorada pelo invasor.
- Avalie se a tentativa teve **sucesso ou falha**:
  - Exemplo: se uma injeção retornou código HTTP 200 com payload grande, há forte risco de sucesso; se retornou 403 ou 400, o ataque foi contido na camada de entrada/WAF.

### 4. Ações de Contenção Imediatas (Hardening Operacional)
Forneça comandos e ações práticas imediatas para estancar o ataque:
- Bloqueio dos IPs maliciosos na borda (ex.: regras IPTables, UFW, regras de WAF no Cloudflare/AWS);
- Revogação de sessões, tokens ou credenciais se houver suspeita de login bem-sucedido;
- Ajuste de rate limiting ou políticas de Fail2ban.

### 5. Medidas Corretivas Definitivas
- Correções no código da aplicação e nos servidores para fechar permanentemente a brecha investigada.

### 6. Oferta de Relatório Técnico (PDF)
- Encerre perguntando se o consultor deseja a emissão do **Relatório Forense de Análise de Logs em formato PDF**, validando se o detalhamento das evidências e das recomendações atende às necessidades da equipe técnica.
