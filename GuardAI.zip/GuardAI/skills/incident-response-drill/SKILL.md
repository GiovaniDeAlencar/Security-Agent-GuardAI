---
name: incident-response-drill
description: Use quando o estudante ou consultor quiser simular ou responder a um incidente de segurança, investigar logs, conter ataques ou entender o ciclo de vida de resposta a incidentes (NIST SP 800-61 / SANS).
---

# Skill: Simulação e Resposta a Incidentes de Segurança

Conduz o estudante ou equipe técnica pelo ciclo de vida formal de resposta a incidentes cibernéticos (baseado no framework NIST SP 800-61 e SANS), treinando a tomada de decisão rápida, contenção e investigação forense.

---

## Quando usar

- "Como responder a um ataque de ransomware ou vazamento de dados em andamento?";
- "Analise estes logs de servidor para identificar um ataque";
- "Simule um exercício prático (tabletop exercise) de resposta a incidentes";
- "O que fazer após identificar uma invasão no sistema?".

---

## As 6 Fases do Ciclo de Resposta (NIST / SANS)

### 1. Preparação (Preparation)
- Verificação de políticas, ferramentas de monitoramento (SIEM, EDR), backups offline testados e canais seguros de comunicação fora de banda.

### 2. Identificação e Triagem (Identification / Detection)
- Análise de indicadores de comprometimento (IoCs) e indicadores de ataque (IoAs).
- Inspeção de logs (acesso web, autenticação, firewall, banco de dados).
- Determinação do escopo: Quais hosts, contas e dados foram afetados?

### 3. Contenção (Containment)
- **Contenção de Curto Prazo:** Isolar máquinas da rede, revogar tokens/sessões ativas, alterar credenciais administrativas comprometidas, bloquear IPs maliciosos na borda/WAF.
- **Contenção de Longo Prazo:** Aplicação de patches emergenciais, isolamento de subsistemas sem desligar servidores (preservando memória volátil para análise forense).

### 4. Erradicação (Eradication)
- Remoção completa de artefatos maliciosos (webshells, cronjobs/tarefas agendadas maliciosas, contas criadas pelo invasor).
- Correção definitiva da vulnerabilidade raiz que permitiu o acesso inicial.

### 5. Recuperação (Recovery)
- Restauração a partir de backups limpos e validados.
- Monitoramento reforçado nas primeiras semanas pós-retorno à produção para detectar tentativas de reinvasão.

### 6. Lições Aprendidas (Lessons Learned / Post-Mortem)
- Reunião de retrospectiva técnica: O que aconteceu? Quando foi detectado? O que funcionou e o que falhou? Como prevenir incidentes idênticos no futuro?
- Documentação do relatório de incidente (Post-Mortem).

---

## Encerramento e Documentação
- Ofereça a consolidação do plano de resposta ou do relatório de post-mortem em formato PDF estruturado, perguntando ao consultor sobre a adequação do layout e das métricas incluídas.
