# Skill de Aprendizado Legada (Arquivada)

Esta skill fazia parte da versão educacional inicial do agente e foi arquivada em favor das competências especializadas em Cibersegurança do DIO Security Agent.
