---
name: powershell-scripting
description: Use quando o analista ou consultor solicitar a criação de um script em PowerShell com base em instruções fornecidas. Desenvolve o script sob medida com boas práticas, solicita a validação do analista e, mediante aprovação e autorização, armazena no repositório com o nome escolhido.
---

# Skill: Criação e Armazenamento de Scripts PowerShell

Atua no desenvolvimento de scripts em **PowerShell** sob medida para o analista, seguindo as melhores práticas de codificação, segurança, parametrização e tratamento de erros. Conduz o fluxo completo: elaboração, validação técnica com o analista e persistência no repositório local.

---

## Quando usar

Use esta skill sempre que o analista ou consultor solicitar:
- "Crie um script PowerShell para [automação, coleta de logs, auditoria, firewall, backup, etc.]";
- "Preciso de um script PowerShell que faça X";
- "Desenvolva uma rotina em PowerShell conforme estas instruções...".

---

## Diretório de Armazenamento Oficial

- **Caminho absoluto do repositório:**
  `C:\Users\giovani.freitas\Documents\Agente\dio-agent-main\dio-agent-main\Repositorio\Scripts`

---

## Fluxo Procedural Obrigatório

O agente deve seguir rigorosamente as etapas abaixo:

### Etapa 1: Elaboração do Script PowerShell
1. Analise cuidadosamente a instrução e os requisitos enviados pelo analista.
2. Escreva o script PowerShell aplicando as melhores práticas da indústria:
   - Uso de `[CmdletBinding()]` e blocos estruturados (`param`, `begin`, `process`, `end`) quando aplicável;
   - Tratamento de exceções com blocos `try { ... } catch { ... }`;
   - Parâmetros tipados e validados (`[ValidateNotNullOrEmpty()]`, etc.);
   - Comentários claros explicando a função e o que cada bloco executa;
   - Práticas de execução segura (ex.: suporte a `-WhatIf` para comandos destrutivos, logs claros de execução).
3. Apresente o código completo no chat com formatação legível.

### Etapa 2: Solicitação de Validação Técnica
- Logo após exibir o código, encerre solicitando explicitamente a avaliação do analista:
  > *"Por favor, valide se o script atende plenamente aos requisitos operacionais ou se há ajustes, novos parâmetros ou comportamentos a alterar."*

### Etapa 3: Oferta de Salvamento no Repositório
- **Se a validação do analista for positiva (aprovação):**
  - Pergunte formalmente se o analista deseja que o script seja guardado no repositório oficial na pasta `C:\Users\giovani.freitas\Documents\Agente\dio-agent-main\dio-agent-main\Repositorio\Scripts`.
  > *"Excelente! O script foi aprovado. Você gostaria que ele fosse salvo no repositório na pasta `Repositorio\Scripts`?"*

### Etapa 4: Coleta do Nome e Persistência do Arquivo
- **Se o analista concordar com o salvamento:**
  1. Peça ao analista para informar o nome desejado para o arquivo (garantindo a extensão `.ps1`, como por exemplo `Audit-FirewallRules.ps1`).
  2. Assim que o analista fornecer o nome (ou se já tiver fornecido):
     - Crie o arquivo diretamente no caminho:
       `C:\Users\giovani.freitas\Documents\Agente\dio-agent-main\dio-agent-main\Repositorio\Scripts\<NomeInformado>.ps1`
     - Salve o conteúdo validado do script com codificação UTF-8.
  3. Confirme ao analista a conclusão do salvamento exibindo o link e o caminho completo do arquivo criado.
