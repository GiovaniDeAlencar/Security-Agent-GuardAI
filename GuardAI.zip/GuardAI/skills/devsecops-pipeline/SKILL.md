---
name: devsecops-pipeline
description: Use quando o estudante ou consultor quiser estruturar segurança contínua no ciclo de desenvolvimento de software (CI/CD), configurando SAST, DAST, SCA, Secrets Detection e Container Scanning.
---

# Skill: Implementação de DevSecOps e Segurança em CI/CD

Orienta arquitetos e desenvolvedores a implementar a cultura de *Shift-Left Security*, integrando verificações automatizadas de segurança diretamente em pipelines (GitHub Actions, GitLab CI, Azure DevOps).

---

## Quando usar

- "Como colocar testes de segurança automáticos no meu GitHub Actions/GitLab CI?";
- "Quais ferramentas open source de SAST/DAST/SCA devo usar no meu projeto?";
- "Como evitar vazamento de chaves de API e senhas nos commits (Secret Scanning)?";
- "Como auditar dependências vulneráveis e imagens Docker no pipeline?".

---

## Os 5 Pilares de Verificação DevSecOps

### 1. Secret Scanning (Detecção de Segredos)
- **Objetivo:** Impedir que credenciais, chaves privadas, certificados ou tokens de nuvem entrem no histórico de controle de versão.
- **Ferramentas de Referência:** Gitleaks, Trufflehog.
- **Prática:** Git pre-commit hooks e checagem bloqueante no PR.

### 2. SCA (Software Composition Analysis - Dependências)
- **Objetivo:** Identificar bibliotecas de terceiros com CVEs conhecidas e gerenciar riscos na cadeia de suprimentos (*Supply Chain Security*).
- **Ferramentas de Referência:** OWASP Dependency-Check, Trivy, Snyk CLI, pip-audit, npm audit.

### 3. SAST (Static Application Security Testing - Código Fonte)
- **Objetivo:** Analisar o código fonte sem executá-lo em busca de más práticas, falhas de injeção, caminhos inseguros e violações de regras OWASP/CWE.
- **Ferramentas de Referência:** Semgrep, SonarQube / SonarCloud, Bandit (Python), ESLint Security plugin (JS/TS), GoSec (Go).

### 4. Container & IaC Scanning (Infraestrutura como Código)
- **Objetivo:** Auditar Dockerfiles, imagens de contêiner e templates Terraform/Kubernetes em busca de configurações perigosas (ex.: rodar como root, portas sensíveis expostas).
- **Ferramentas de Referência:** Trivy, Checkov, Hadolint, KICS.

### 5. DAST (Dynamic Application Security Testing)
- **Objetivo:** Testar a aplicação rodando contra ataques conhecidos via endpoints web/API.
- **Ferramentas de Referência:** OWASP ZAP (Zed Attack Proxy), Nikto.

---

## Estrutura de Resposta
1. **Recomendação de Ferramentas:** Sugira ferramentas ideais para a linguagem/stack informada (preferencialmente open source e compatíveis com CI).
2. **Exemplo de Pipeline Real:** Forneça o arquivo de configuração prático (ex.: `.github/workflows/security.yml` comentado).
3. **Gestão de Falsos Positivos e Quality Gates:** Explique como definir thresholds de severidade (ex.: bloquear merge apenas para falhas Críticas e Altas para não paralisar o time).
4. **Relatório em PDF:** Pergunte se o consultor deseja um documento executivo com as recomendações de DevSecOps e a política de segurança para o repositório em PDF.
