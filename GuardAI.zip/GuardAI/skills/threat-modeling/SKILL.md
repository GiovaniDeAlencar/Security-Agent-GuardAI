---
name: threat-modeling
description: Use quando o estudante ou consultor quiser avaliar a arquitetura, desenho técnico, fluxo de dados ou sistema para identificar ameaças antes da implementação, usando a metodologia STRIDE e boas práticas de Security by Design.
---

# Skill: Modelagem de Ameaças (Threat Modeling) com STRIDE

Atua como arquiteto de segurança da informação para mapear fluxos de dados, componentes e fronteiras de confiança (*trust boundaries*), identificando ameaças potenciais e desenhando controles preventivos antes ou durante a construção do software.

---

## Quando usar

- "Como posso fazer a modelagem de ameaças desta arquitetura/API/sistema?";
- "Avalie os riscos de segurança deste desenho de solução";
- "Quais são as ameaças de segurança neste fluxo de autenticação/pagamento?";
- "Aplique o modelo STRIDE neste cenário".

---

## Processo de Análise

### 1. Decomposição do Sistema
- Identifique os **Atores** (usuários anônimos, autenticados, administradores, serviços terceiros);
- Mapeie os **Componentes e Processos** (APIs, microsserviços, workers, bancos de dados, filas);
- Defina as **Fronteiras de Confiança (Trust Boundaries)** (ex.: Internet vs. Rede Privada, Frontend vs. Backend, Aplicação vs. Banco de Dados);
- Rastreie o **Fluxo de Dados Sensíveis** (senhas, tokens, dados pessoais/PII, transações).

### 2. Aplicação da Matriz STRIDE

Analise o sistema sob cada uma das 6 categorias do STRIDE:

| Letra | Ameaça | Pergunta Chave | Controles Recomendados |
|---|---|---|---|
| **S** | **Spoofing** (Falsificação) | Um atacante pode se passar por outro usuário ou serviço? | Autenticação multifator (MFA), JWT assinado com chave assimétrica, mTLS. |
| **T** | **Tampering** (Adulteração) | Os dados podem ser modificados em trânsito ou repouso sem detecção? | TLS 1.3, assinaturas digitais, hashes/HMAC, integridade de banco de dados. |
| **R** | **Repudiation** (Repúdio) | Um usuário pode realizar uma ação crítica e negar que a fez? | Trilha de auditoria centralizada (logs append-only), carimbo de tempo, correlation IDs. |
| **I** | **Information Disclosure** (Vazamento) | Dados sensíveis podem ser lidos por pessoas ou serviços não autorizados? | Criptografia em repouso (AES-256), ofuscação/mascaramento de logs, controle de acesso estrito. |
| **D** | **Denial of Service** (Negação de Serviço) | O serviço pode ser exaurido ou derrubado por sobrecarga? | Rate limiting, circuit breakers, paginação estrita, proteção contra DDoS. |
| **E** | **Elevation of Privilege** (Elevação de Privilégio) | Um usuário comum pode assumir funções de administrador? | RBAC/ABAC rigoroso, validação no backend (nunca confiar no frontend), PoLP. |

### 3. Matriz de Risco e Priorização
- Classifique cada ameaça encontrada por Severidade (Crítica, Alta, Média, Baixa) com base na probabilidade de exploração e impacto no negócio.

### 4. Plano de Mitigação e Recomendações
- Forneça recomendações práticas e acionáveis para o time de engenharia implementar as defesas necessárias.

### 5. Oferta de Relatório Técnico (PDF)
- Ao final, pergunte se o consultor deseja exportar o modelo de ameaças gerado em formato de relatório técnico executivo em PDF, validando o layout e a profundidade das informações.
