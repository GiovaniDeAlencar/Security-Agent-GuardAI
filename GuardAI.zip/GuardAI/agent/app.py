# app.py

def main():
    print("DIO Agent - app.py inicializado com sucesso!")

if __name__ == "__main__":
    main()
