# Frameworks, Padrões e Referências de Cibersegurança

Este arquivo serve como base de conhecimento de referência para o DIO Agent aplicar análises técnicas, modelagens de ameaças e auditorias de código com padrões globais de segurança da informação.

---

## 1. Classificação de Falhas e Vulnerabilidades

### OWASP (Open Web Application Security Project)
- **OWASP Top 10 Web (2021/atual):**
  - A01: Broken Access Control (Controle de Acesso Quebrado - falha mais comum no mercado, incluindo IDOR).
  - A02: Cryptographic Failures (Falhas Criptográficas - dados sensíveis expostos, cifras fracas, ausência de TLS).
  - A03: Injection (Injeção de SQL, NoSQL, OS Command, LDAP).
  - A04: Insecure Design (Design Inseguro - falhas arquiteturais, ausência de modelagem de ameaças).
  - A05: Security Misconfiguration (Configuração Incorreta - credenciais padrão, debug ativo, portas abertas).
  - A06: Vulnerable and Outdated Components (Componentes Vulneráveis - bibliotecas desatualizadas, riscos de cadeia de suprimentos).
  - A07: Identification and Authentication Failures (Falhas de Autenticação - MFA ausente, força bruta, sessões previsíveis).
  - A08: Software and Data Integrity Failures (Falhas de Integridade - pipelines CI/CD inseguros, desserialização insegura).
  - A09: Security Logging and Monitoring Failures (Monitoramento Inadequado - ausência de trilhas de auditoria).
  - A10: Server-Side Request Forgery (SSRF - requisições forçadas do servidor a recursos internos/externos).
- **OWASP API Security Top 10:** Atenção especial para BOLA (Broken Object Level Authorization), Broken Authentication, Mass Assignment e Lack of Resources/Rate Limiting.

### CWE (Common Weakness Enumeration) & CVE (Common Vulnerabilities and Exposures)
- Utilizar os identificadores oficiais do MITRE (ex.: CWE-89 para SQLi, CWE-79 para XSS, CWE-22 para Path Traversal, CWE-502 para Desserialização Insegura).
- Vincular a CVEs públicas conhecidas quando houver bibliotecas de terceiros afetadas.

---

## 2. Quantificação de Risco: CVSS (Common Vulnerability Scoring System)

Ao avaliar falhas, considere o vetor de métricas básicas do **CVSS v3.1 / v4.0**:

- **Métricas de Exploitability:**
  - **Attack Vector (AV):** Network (N), Adjacent (A), Local (L), Physical (P).
  - **Attack Complexity (AC):** Low (L), High (H).
  - **Privileges Required (PR):** None (N), Low (L), High (H).
  - **User Interaction (UI):** None (N), Required (R).
- **Métricas de Impacto:**
  - **Confidentiality (C):** None (N), Low (L), High (H).
  - **Integrity (I):** None (N), Low (L), High (H).
  - **Availability (A):** None (N), Low (L), High (H).

### Tabela de Severidade:
- **0.0:** Informativa (Info)
- **0.1 - 3.9:** Baixa (Low)
- **4.0 - 6.9:** Média (Medium)
- **7.0 - 8.9:** Alta (High)
- **9.0 - 10.0:** Crítica (Critical)

---

## 3. Matrizes Táticas e Operacionais

### MITRE ATT&CK
Para contextualizar ataques em relatórios e análises, correlacione com as táticas do adversário:
1. Reconnaissance (Reconhecimento)
2. Initial Access (Acesso Inicial - phishing, exploração de app voltada para web)
3. Execution (Execução - linha de comando, scripts maliciosos)
4. Persistence (Persistência)
5. Privilege Escalation (Escalação de Privilégios)
6. Defense Evasion (Evasão de Defesa)
7. Credential Access (Acesso a Credenciais - dump de senhas, força bruta)
8. Discovery (Descoberta)
9. Lateral Movement (Movimentação Lateral)
10. Collection (Coleta de Dados)
11. Command and Control (C2)
12. Exfiltration (Exfiltração)
13. Impact (Impacto - cifragem/ransomware, indisponibilidade)

---

## 4. Modelagem de Ameaças (Threat Modeling)

- **Metodologia STRIDE (Microsoft):**
  - **S**poofing (Falsificação de Identidade) -> Mitigação: Autenticação forte.
  - **T**ampering (Adulteração de Dados) -> Mitigação: Integridade, assinaturas digitais, HMAC.
  - **R**epudiation (Repúdio) -> Mitigação: Auditoria e logging não-repudiável.
  - **I**nformation Disclosure (Vazamento de Informação) -> Mitigação: Criptografia em trânsito e em repouso.
  - **D**enial of Service (Negação de Serviço) -> Mitigação: Rate limiting, resiliência, redundância.
  - **E**levation of Privilege (Elevação de Privilégio) -> Mitigação: Princípio do menor privilégio, RBAC/ABAC.

---

## 5. Princípios de Engenharia de Segurança

- **Defesa em Profundidade (Defense in Depth):** Múltiplas camadas de controle de segurança (ex.: validação no cliente, sanitização/parameterização no servidor, WAF, banco com usuário de menor privilégio).
- **Security by Design & by Default:** Segurança pensada desde a concepção da arquitetura, e configurações mais seguras ativadas por padrão.
- **Princípio do Menor Privilégio (PoLP):** Usuários, serviços e processos devem ter acesso estritamente ao que precisam para funcionar.
- **Fail Securely:** O sistema deve falhar fechado (bloquear o acesso em caso de erro, e nunca expor stack traces informativas a usuários externos).
